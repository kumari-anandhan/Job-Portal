import os
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_absolute_error
import joblib

BASE_DIR = os.path.dirname(os.path.abspath(__file__))

# Go one folder back to job_portal
CSV_PATH = os.path.join(BASE_DIR, "..", "job_dataset.csv")

MODEL_DIR = os.path.join(BASE_DIR, "ml_models")
os.makedirs(MODEL_DIR, exist_ok=True)
MODEL_PATH = os.path.join(MODEL_DIR, "salary_model.pkl")

df = pd.read_csv(CSV_PATH)

features = ["job_title", "city", "experience_years", "skills_count", "company_type", "job_type"]
target = "salary_lpa"

X = df[features]
y = df[target]

cat_cols = ["job_title", "city", "company_type", "job_type"]
num_cols = ["experience_years", "skills_count"]

preprocess = ColumnTransformer(
    transformers=[
        ("cat", OneHotEncoder(handle_unknown="ignore"), cat_cols),
        ("num", "passthrough", num_cols),
    ]
)

model = RandomForestRegressor(n_estimators=300, random_state=42, n_jobs=-1)
pipe = Pipeline(steps=[("prep", preprocess), ("model", model)])

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

pipe.fit(X_train, y_train)
pred = pipe.predict(X_test)
mae = mean_absolute_error(y_test, pred)

joblib.dump(pipe, MODEL_PATH)
print("✅ Saved:", MODEL_PATH)
print("✅ Salary MAE (LPA):", round(mae, 2))