import os
import pandas as pd
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_absolute_error
import joblib

# CSV path (relative to ml_training folder)
BASE_DIR = os.path.dirname(os.path.abspath(__file__))           # E:\job_portal\ml_training
CSV_PATH = os.path.join(BASE_DIR, "..", "job_dataset.csv")      # E:\job_portal\job_dataset.csv

# Model save path (auto create folder)
MODEL_DIR = os.path.join(BASE_DIR, "ml_models")
os.makedirs(MODEL_DIR, exist_ok=True)
MODEL_PATH = os.path.join(MODEL_DIR, "city_demand_model.pkl")

df = pd.read_csv(CSV_PATH)
df["posted_date"] = pd.to_datetime(df["posted_date"])

daily = (
    df.groupby(["city", "posted_date"])
      .size()
      .reset_index(name="job_count")
      .sort_values(["city", "posted_date"])
)

models = {}
metrics = {}

for city, cdf in daily.groupby("city"):
    cdf = cdf.sort_values("posted_date").reset_index(drop=True)

    base_date = cdf["posted_date"].min()
    cdf["day_idx"] = (cdf["posted_date"] - base_date).dt.days

    cdf["lag1"] = cdf["job_count"].shift(1)
    cdf["lag7"] = cdf["job_count"].shift(7)
    cdf2 = cdf.dropna()

    if len(cdf2) < 10:
        baseline = float(cdf["job_count"].mean())
        models[city] = {
            "type": "baseline",
            "baseline": baseline,
            "base_date": base_date,
            "last_known": cdf.tail(7)[["posted_date", "job_count"]],
        }
        metrics[city] = {"mode": "baseline", "avg": baseline, "rows": int(len(cdf))}
        continue

    X = cdf2[["day_idx", "lag1", "lag7"]]
    y = cdf2["job_count"]

    model = LinearRegression()
    model.fit(X, y)

    pred = model.predict(X)
    mae = mean_absolute_error(y, pred)

    models[city] = {
        "type": "lr",
        "model": model,
        "base_date": base_date,
        "last_known": cdf.tail(7)[["posted_date", "job_count"]],
    }
    metrics[city] = {"mode": "lr", "mae": float(mae), "train_rows": int(len(cdf2))}

joblib.dump({"models": models, "metrics": metrics}, MODEL_PATH)
print("✅ Saved:", MODEL_PATH)
print("✅ Cities:", list(models.keys()))