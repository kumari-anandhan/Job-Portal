from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import authenticate, login, logout
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.views.decorators.http import require_http_methods

from .forms import (
    CompanyRegisterForm,
    SeekerRegisterForm,
    CompanyProfileForm,
    SeekerProfileForm,
)
from .models import CompanyProfile, SeekerProfile
from jobs.models import Job, JobApplication

# ML import safe
try:
    from jobs.utils.ml import predict_salary
except Exception as e:
    predict_salary = None
    print("⚠️ ML import error:", e)

# ✅ IMPORT CORRECT ATS FUNCTIONS
from .utils import (
    ROLE_SKILLS,
    ROLE_NAME_MAP,
    extract_text_from_pdf,
    extract_text_from_docx,
    ats_score_resume,
)

# ---------------------------
# Auth / Register
# ---------------------------

def register_company(request):
    form = CompanyRegisterForm(request.POST or None)

    if request.method == "POST":
        if form.is_valid():
            user = form.save()
            login(request, user)

            CompanyProfile.objects.get_or_create(
                user=user,
                defaults={"company_name": form.cleaned_data["company_name"]},
            )

            messages.success(request, "Company registered successfully.")
            return redirect("company_dashboard")

        messages.error(request, "Please correct the errors below.")

    return render(request, "accounts/register_company.html", {"form": form})


def register_seeker(request):
    form = SeekerRegisterForm(request.POST or None)

    if request.method == "POST" and form.is_valid():
        user = form.save()
        login(request, user)

        SeekerProfile.objects.get_or_create(
            user=user,
            defaults={"full_name": user.username},
        )

        messages.success(request, "Job seeker registered successfully.")
        return redirect("seeker_dashboard")

    return render(request, "accounts/register_seeker.html", {"form": form})


# ---------------------------
# Login / Logout
# ---------------------------

@require_http_methods(["GET", "POST"])
def login_view(request):
    if request.method == "POST":
        user = authenticate(
            request,
            username=request.POST.get("username"),
            password=request.POST.get("password"),
        )

        if not user:
            messages.error(request, "Invalid username or password.")
            return render(request, "accounts/login.html")

        login(request, user)

        if getattr(user, "role", None) == "COMPANY":
            return redirect("company_dashboard")
        return redirect("seeker_dashboard")

    return render(request, "accounts/login.html")


def logout_view(request):
    logout(request)
    return redirect("login")


@login_required
def redirect_after_login(request):
    if getattr(request.user, "role", None) == "COMPANY":
        return redirect("company_dashboard")
    return redirect("seeker_dashboard")


# ---------------------------
# Dashboards
# ---------------------------

@login_required
def company_dashboard(request):
    if getattr(request.user, "role", None) != "COMPANY":
        return redirect("redirect_after_login")

    profile = get_object_or_404(CompanyProfile, user=request.user)

    return render(request, "accounts/company_dashboard.html", {
        "profile": profile
    })


@login_required
def seeker_dashboard(request):
    if getattr(request.user, "role", None) != "SEEKER":
        return redirect("login")

    profile, _ = SeekerProfile.objects.get_or_create(
        user=request.user,
        defaults={"full_name": request.user.username},
    )

    jobs = Job.objects.all().order_by("-id")

    return render(request, "accounts/seeker_dashboard.html", {
        "profile": profile,
        "jobs": jobs,
    })


# ---------------------------
# Profile Edit
# ---------------------------

@login_required
def edit_company_profile(request):
    profile = get_object_or_404(CompanyProfile, user=request.user)

    form = CompanyProfileForm(request.POST or None, instance=profile)

    if request.method == "POST" and form.is_valid():
        form.save()
        return redirect("company_dashboard")

    return render(request, "accounts/edit_company_profile.html", {"form": form})


@login_required
def edit_seeker_profile(request):
    profile, _ = SeekerProfile.objects.get_or_create(
        user=request.user,
        defaults={"full_name": request.user.username},
    )

    form = SeekerProfileForm(request.POST or None, request.FILES or None, instance=profile)

    if request.method == "POST" and form.is_valid():
        form.save()
        messages.success(request, "Profile updated!")
        return redirect("seeker_dashboard")

    return render(request, "accounts/edit_seeker_profile.html", {
        "form": form,
        "profile": profile,
    })


# ---------------------------
# ✅ ATS RESUME (FIXED)
# ---------------------------

@login_required
def ats_resume_view(request):

    if request.method == "GET":
        return render(request, "accounts/ats_resume.html", {"result": None})

    role_key = request.POST.get("role_choice")
    resume_file = request.FILES.get("resume")

    if role_key not in ROLE_SKILLS:
        messages.error(request, "Select role")
        return redirect("ats_resume")

    if not resume_file:
        messages.error(request, "Upload resume")
        return redirect("ats_resume")

    # ✅ Extract REAL text
    if resume_file.name.endswith(".pdf"):
        resume_text = extract_text_from_pdf(resume_file)
    elif resume_file.name.endswith(".docx"):
        resume_text = extract_text_from_docx(resume_file)
    else:
        messages.error(request, "Only PDF/DOCX allowed")
        return redirect("ats_resume")

    if not resume_text.strip():
        messages.error(request, "Resume not readable")
        return redirect("ats_resume")

    skills = ROLE_SKILLS[role_key]

    # simple job description
    jd_text = " ".join(skills)

    # ✅ REAL ATS SCORE
    result = ats_score_resume(resume_text, jd_text, skills)

    result["resume_name"] = resume_file.name

    return render(request, "accounts/ats_resume.html", {
        "role_key": role_key,
        "role_name": ROLE_NAME_MAP[role_key],
        "role_skills": skills,
        "result": result,
    })


# ---------------------------
# Salary Predictor
# ---------------------------

@login_required
def salary_predict_view(request):
    if predict_salary is None:
        return render(request, "jobs/salary_predict.html", {"predicted": None})

    predicted = None

    if request.method == "POST":
        payload = {
            "job_title": request.POST.get("job_title"),
            "city": request.POST.get("city"),
            "experience_years": int(request.POST.get("experience_years", 0)),
            "skills_count": int(request.POST.get("skills_count", 0)),
            "company_type": request.POST.get("company_type"),
            "job_type": request.POST.get("job_type"),
        }
        predicted = round(predict_salary(payload), 2)

    return render(request, "jobs/salary_predict.html", {"predicted": predicted})


# ---------------------------
# Apply Job
# ---------------------------

@login_required
def job_apply(request, job_id):
    job = get_object_or_404(Job, id=job_id)
    messages.success(request, f"Applied to {job.title}")
    return redirect("seeker_dashboard")


# ---------------------------
# Company Applications
# ---------------------------

@login_required
def company_applications(request):
    applications = JobApplication.objects.filter(
        job__company=request.user
    ).order_by("-applied_at")

    return render(request, "company/applications.html", {
        "applications": applications
    })
    

import requests

def fetch_jobs(skill="Java Developer", location="Chennai"):
    url = "https://api.adzuna.com/v1/api/jobs/in/search/1"

    params = {
        "app_id": "YOUR_APP_ID",
        "app_key": "YOUR_APP_KEY",
        "what": skill,
        "where": location,
    }

    response = requests.get(url, params=params)
    data = response.json()

    jobs = data.get("results", [])

    if not jobs:
        return "Currently no jobs found, but common roles are Java Developer, Python Developer."

    result = " Latest Jobs in Chennai:\n\n"

    for job in jobs[:5]:
        result += f"{job['title']} at {job['company']['display_name']}\n"
        result += f" {job['location']['display_name']}\n"
        result += f"Apply: {job['redirect_url']}\n\n"

    return result

def chatbot_view(request):
    if request.method == "POST":
        user_input = request.POST.get("message")

        if "job" in user_input.lower():
            reply = fetch_jobs()   # 👈 CALL HERE
        else:
            reply = "Ask about jobs like 'Show jobs in Chennai'"

        return JsonResponse({"response": reply})

from django.http import JsonResponse
import requests

def jobs_api(request):
    skill = request.GET.get("skill", "Java Developer")
    location = request.GET.get("location", "Chennai")

    url = "https://api.adzuna.com/v1/api/jobs/in/search/1"

    params = {
        "app_id": "YOUR_APP_ID",
        "app_key": "YOUR_APP_KEY",
        "what": skill,
        "where": location,
    }

    response = requests.get(url, params=params)
    data = response.json()

    jobs = []

    for job in data.get("results", [])[:5]:
        jobs.append({
            "title": job.get("title"),
            "company": job.get("company", {}).get("display_name"),
            "location": job.get("location", {}).get("display_name"),
            "link": job.get("redirect_url"),
        })

    return JsonResponse({"jobs": jobs})