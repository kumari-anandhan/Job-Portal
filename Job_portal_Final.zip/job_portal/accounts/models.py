from django.db import models
from django.contrib.auth.models import AbstractUser
from django.conf import settings
from jobs.models import Job


class User(AbstractUser):
    ROLE_CHOICES = (
        ("COMPANY", "Company"),
        ("SEEKER", "Job Seeker"),
    )
    role = models.CharField(max_length=20, choices=ROLE_CHOICES, default="SEEKER")

    def __str__(self):
        return self.username


from django.db import models
from django.conf import settings

class CompanyProfile(models.Model):
    user = models.OneToOneField(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)
    company_name = models.CharField(max_length=200)
    website = models.URLField(blank=True)
    location = models.CharField(max_length=200, blank=True)
    description = models.TextField(blank=True)

    def __str__(self):
        return self.company_name


class SeekerProfile(models.Model):
    user = models.OneToOneField(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)

    ROLE_CHOICES = [
        ("PYTHON_DEV", "Python Developer"),
        ("JAVA_DEV", "Java Developer"),
        ("FULLSTACK", "Full Stack Developer"),
        ("UIUX", "UI/UX Designer"),
        ("DATA", "Data Analyst"),
        ("ML", "Machine Learning Engineer"),
    ]

    role_interest = models.CharField(max_length=30, choices=ROLE_CHOICES, blank=True, null=True)
    full_name = models.CharField(max_length=200, blank=True)
    skills = models.TextField(blank=True)
    resume_link = models.URLField(blank=True, null=True)
    resume_file = models.FileField(upload_to="resumes/", blank=True, null=True)
    about = models.TextField(blank=True)
    certification_link = models.URLField(blank=True, null=True)
    certification_file = models.FileField(upload_to="certifications/", blank=True, null=True)

    def __str__(self):
        return self.user.username


class ATSResult(models.Model):
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)
    job = models.ForeignKey(Job, on_delete=models.CASCADE, null=True, blank=True)

    resume_name = models.CharField(max_length=255, blank=True)
    resume_text = models.TextField(blank=True)

    ats_score = models.IntegerField(default=0)
    skill_match = models.IntegerField(default=0)
    keyword_match = models.IntegerField(default=0)

    matched_skills = models.JSONField(default=list, blank=True)
    missing_skills = models.JSONField(default=list, blank=True)

    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.user} - {self.ats_score}"