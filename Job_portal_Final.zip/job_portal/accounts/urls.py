from django.urls import path
from . import views
from .views import chatbot_view, jobs_api
urlpatterns = [
    # Auth / Register
    path("register/company/", views.register_company, name="register_company"),
    path("register/seeker/", views.register_seeker, name="register_seeker"),
    path("login/", views.login_view, name="login"),
    path("logout/", views.logout_view, name="logout"),
    path("redirect/", views.redirect_after_login, name="redirect_after_login"),

    # Dashboards
    path("dashboard/company/", views.company_dashboard, name="company_dashboard"),
    path("dashboard/seeker/", views.seeker_dashboard, name="seeker_dashboard"),

    # Profile edit
    path("profile/company/edit/", views.edit_company_profile, name="edit_company_profile"),
    path("profile/seeker/edit/", views.edit_seeker_profile, name="edit_seeker_profile"),

    # ATS Resume Analyzer (in accounts app based on your views.py)
    path("ats-resume/", views.ats_resume_view, name="ats_resume"),

    # Analytics + Salary (also in accounts views.py based on your code)

    path("salary-predict/", views.salary_predict_view, name="salary_predict"),
    
    path('chat/', chatbot_view, name='chat'),
    path('api/jobs/', jobs_api, name='jobs_api'),
    

]