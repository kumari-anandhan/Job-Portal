import re
from collections import Counter
import pdfplumber
from docx import Document

# ✅ AI import
from sentence_transformers import SentenceTransformer, util

# ✅ Load AI model (only once)
model = SentenceTransformer('all-MiniLM-L6-v2')


# -----------------------------
# 1) Resume Text Extraction
# -----------------------------
def extract_text_from_pdf(file_obj):
    text = ""
    try:
        with pdfplumber.open(file_obj) as pdf:
            for page in pdf.pages:
                page_text = page.extract_text()
                if page_text:
                    text += page_text + "\n"
    except Exception as e:
        print("PDF read error:", e)

    return text.strip()


def extract_text_from_docx(file_obj):
    text = ""
    try:
        doc = Document(file_obj)
        text = "\n".join(p.text for p in doc.paragraphs if p.text)
    except Exception as e:
        print("DOCX read error:", e)

    return text.strip()


def clean_text(t: str) -> str:
    t = (t or "").lower()
    t = re.sub(r"[^a-zA-Z0-9\s]", " ", t)
    t = re.sub(r"\s+", " ", t).strip()
    return t


# -----------------------------
# 2) Role → Skills Mapping
# -----------------------------
ROLE_SKILLS = {
    "PYTHON_DEV": ["python", "django", "flask", "rest api", "sql", "git", "html", "css", "javascript"],
    "JAVA_DEV": ["java", "spring", "spring boot", "hibernate", "rest api", "sql", "git", "maven", "microservices"],
    "FULLSTACK": ["html", "css", "javascript", "react", "node", "api", "sql", "git"],
    "UIUX": ["figma", "wireframe", "prototype", "user research", "ui design", "ux design", "usability"],
    "DATA": ["excel", "sql", "power bi", "tableau", "python", "pandas", "data cleaning", "dashboard"],
    "ML": ["python", "numpy", "pandas", "scikit-learn", "nlp", "classification", "model training", "deployment"],
}

ROLE_NAME_MAP = {
    "PYTHON_DEV": "Python Developer",
    "JAVA_DEV": "Java Developer",
    "FULLSTACK": "Full Stack Developer",
    "UIUX": "UI/UX Designer",
    "DATA": "Data Analyst",
    "ML": "Machine Learning Engineer",
}


# -----------------------------
# 3) Keyword Matching
# -----------------------------
def _keyword_match_percent(resume: str, jd: str, top_n: int = 30) -> int:
    jd_tokens = re.findall(r"[a-zA-Z]{3,}", jd)
    if not jd_tokens:
        return 0

    resume_tokens = set(re.findall(r"[a-zA-Z]{3,}", resume))
    top_keywords = [w for w, _ in Counter(jd_tokens).most_common(top_n)]

    found = sum(1 for w in top_keywords if w in resume_tokens)
    return int((found / len(top_keywords)) * 100)


# -----------------------------
# 4) BASIC ATS Score
# -----------------------------
def ats_score_resume(resume_text: str, jd_text: str, skills_list: list):
    resume = clean_text(resume_text)
    jd = clean_text(jd_text)

    matched = []
    missing = []

    resume_compact = resume.replace(" ", "")

    for skill in skills_list:
        s = skill.lower().strip()
        s_compact = s.replace(" ", "")

        if s in resume or s_compact in resume_compact:
            matched.append(skill)
        else:
            missing.append(skill)

    skill_match_percent = int((len(matched) / max(len(skills_list), 1)) * 100)
    keyword_match_percent = _keyword_match_percent(resume, jd)

    final_score = int((0.65 * skill_match_percent) + (0.35 * keyword_match_percent))

    return {
        "ats_score": max(0, min(final_score, 100)),
        "skill_match": skill_match_percent,
        "keyword_match": keyword_match_percent,
        "matched_skills": matched,
        "missing_skills": missing,
    }


# -----------------------------
# 5) AI ATS Score (REAL ATS)
# -----------------------------
def ai_ats_score(resume_text: str, jd_text: str):
    try:
        resume_embedding = model.encode(resume_text, convert_to_tensor=True)
        jd_embedding = model.encode(jd_text, convert_to_tensor=True)

        similarity = util.cos_sim(resume_embedding, jd_embedding).item()

        score = int((similarity + 1) / 2 * 100)
        return max(0, min(score, 100))

    except Exception as e:
        print("AI error:", e)
        return 0


# -----------------------------
# 6) FINAL COMBINED SCORE
# -----------------------------
def final_ats_score(resume_text, jd_text, skills):
    basic = ats_score_resume(resume_text, jd_text, skills)

    ai_score = ai_ats_score(resume_text, jd_text)

    final_score = int((0.6 * basic["ats_score"]) + (0.4 * ai_score))

    basic["ai_score"] = ai_score
    basic["ats_score"] = final_score

    return basic


# -----------------------------
# 7) Suggestions
# -----------------------------
def get_resume_suggestions(missing_skills):
    if not missing_skills:
        return ["Great! Your resume matches well."]

    suggestions = []
    for skill in missing_skills[:5]:
        suggestions.append(f"Add projects or experience in {skill}")

    return suggestions