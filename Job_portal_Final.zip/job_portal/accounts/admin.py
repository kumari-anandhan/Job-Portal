from django.contrib import admin
from django.contrib.auth import get_user_model

from .models import SeekerProfile, ATSResult

from .models import CompanyProfile  # keep separate so you notice if name mismatch

User = get_user_model()


@admin.register(User)
class UserAdmin(admin.ModelAdmin):
    list_display = ("id", "username", "email", "role", "is_staff", "is_active")
    search_fields = ("username", "email")
    list_filter = ("role", "is_staff", "is_active")


@admin.register(CompanyProfile)
class CompanyProfileAdmin(admin.ModelAdmin):
    list_display = ("id", "company_name", "user")
    search_fields = ("company_name", "user__username", "user__email")


@admin.register(SeekerProfile)
class SeekerProfileAdmin(admin.ModelAdmin):
    list_display = ("id", "full_name", "user", "role_interest")
    search_fields = ("full_name", "user__username", "user__email")
    list_filter = ("role_interest",)


@admin.register(ATSResult)
class ATSResultAdmin(admin.ModelAdmin):
    list_display = ("id", "user", "ats_score", "created_at")
    search_fields = ("user__username", "resume_name")
    list_filter = ("created_at",)