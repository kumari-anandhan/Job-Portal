from django import forms
from django.contrib.auth import get_user_model
from django.contrib.auth.forms import UserCreationForm

from .models import CompanyProfile, SeekerProfile

User = get_user_model()


# ---------------------------
# Register Forms
# ---------------------------

from django import forms
from django.contrib.auth import get_user_model
from django.contrib.auth.forms import UserCreationForm

User = get_user_model()


class CompanyRegisterForm(UserCreationForm):
    company_name = forms.CharField(
        max_length=200,
        required=True,
        widget=forms.TextInput(attrs={"class": "form-control", "placeholder": "Company Name"}),
    )

    email = forms.EmailField(
        required=True,
        widget=forms.EmailInput(attrs={"class": "form-control", "placeholder": "Email"}),
    )

    class Meta:
        model = User
        fields = ["company_name", "email", "password1", "password2"]

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields["password1"].widget.attrs.update({"class": "form-control", "placeholder": "Password"})
        self.fields["password2"].widget.attrs.update({"class": "form-control", "placeholder": "Confirm Password"})

    def save(self, commit=True):
        user = super().save(commit=False)

        user.role = "COMPANY"
        user.email = self.cleaned_data["email"]

        # auto create username from company_name
        name = self.cleaned_data["company_name"].strip()
        base = "".join(ch for ch in name.lower() if ch.isalnum())
        if not base:
            base = "company"

        username = base
        i = 1
        while User.objects.filter(username=username).exists():
            i += 1
            username = f"{base}{i}"

        user.username = username

        if commit:
            user.save()
        return user

class SeekerRegisterForm(UserCreationForm):
    full_name = forms.CharField(
        max_length=200,
        required=True,
        widget=forms.TextInput(attrs={"class": "form-control", "placeholder": "Full Name"}),
    )
    email = forms.EmailField(
        required=True,
        widget=forms.EmailInput(attrs={"class": "form-control", "placeholder": "Email"}),
    )

    class Meta:
        model = User
        fields = ["username", "email", "full_name", "password1", "password2"]

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields["username"].widget.attrs.update({"class": "form-control", "placeholder": "Username"})
        self.fields["password1"].widget.attrs.update({"class": "form-control"})
        self.fields["password2"].widget.attrs.update({"class": "form-control"})

    def save(self, commit=True):
        user = super().save(commit=False)
        user.role = "SEEKER"
        user.email = self.cleaned_data["email"]
        if commit:
            user.save()
        return user


# ---------------------------
# Profile Update Forms
# ---------------------------

class CompanyProfileForm(forms.ModelForm):
    class Meta:
        model = CompanyProfile
        fields = ["company_name", "website", "location", "description"]

        widgets = {
            "company_name": forms.TextInput(attrs={"class": "form-control", "placeholder": "Company Name"}),
            "website": forms.URLInput(attrs={"class": "form-control", "placeholder": "https://example.com"}),
            "location": forms.TextInput(attrs={"class": "form-control", "placeholder": "City / Location"}),
            "description": forms.Textarea(attrs={"class": "form-control", "rows": 4, "placeholder": "About company..."}),
        }


from django import forms
from .models import SeekerProfile

class SeekerProfileForm(forms.ModelForm):
    class Meta:
        model = SeekerProfile
        fields = [
            "full_name",
            "role_interest",
            "skills",
            "about",                 # ✅ NEW
            "resume_link",
            "resume_file",
            "certification_link",    # ✅ NEW
            "certification_file",    # ✅ NEW
        ]

        widgets = {
            "full_name": forms.TextInput(attrs={
                "class": "form-control",
                "placeholder": "Full Name"
            }),
            "role_interest": forms.Select(attrs={
                "class": "form-select"
            }),
            "skills": forms.Textarea(attrs={
                "class": "form-control",
                "rows": 3,
                "placeholder": "Python, Django, SQL..."
            }),

            # ✅ NEW
            "about": forms.Textarea(attrs={
                "class": "form-control",
                "rows": 4,
                "placeholder": "Short profile summary (About you)..."
            }),

            "resume_link": forms.URLInput(attrs={
                "class": "form-control",
                "placeholder": "https://..."
            }),
            "resume_file": forms.ClearableFileInput(attrs={
                "class": "form-control"
            }),

            # ✅ NEW
            "certification_link": forms.URLInput(attrs={
                "class": "form-control",
                "placeholder": "https://certificate-link..."
            }),
            "certification_file": forms.ClearableFileInput(attrs={
                "class": "form-control"
            }),
        }


    
    
