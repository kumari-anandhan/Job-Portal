from django.conf import settings
from django.contrib.staticfiles.storage import staticfiles_storage
from django.urls import path
from django.conf.urls.static import static
from . import views

urlpatterns = [
    path("", views.job_list_public, name="job_list_public"),

    path("company/jobs/", views.company_jobs, name="company_jobs"),
    path("company/jobs/new/", views.job_create, name="job_create"),
    path("company/jobs/<int:id>/edit/", views.edit_job, name="edit_job"),
    path("company/jobs/<int:id>/delete/", views.delete_job, name="delete_job"),

    path("company/jobs/<int:job_id>/applicants/", views.job_applicants, name="job_applicants"),
    path("apply/<int:job_id>/", views.apply_job, name="job_apply"),
    path("salary-predict/", views.salary_predict_view, name="salary_predict"),
    path("city-map/", views.city_map_view, name="city_map"),
    path("city-demand/", views.city_demand_view, name="city_demand"), 
    path("api/jobs/", views.jobs_api, name="jobs_api"),
  
]

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)