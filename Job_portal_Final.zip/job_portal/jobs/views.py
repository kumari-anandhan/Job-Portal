from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.http import JsonResponse
from django.views.decorators.http import require_GET

from accounts.models import SeekerProfile
from .forms import JobForm
from .models import Job, JobApplication

from .utils.ml import (
    city_reduction_analysis,
    predict_salary,
    forecast_city_role,
    load_city_role_options,
)


# -----------------------------
# Public Job List
# -----------------------------
def job_list_public(request):
    jobs = Job.objects.filter(is_active=True).order_by("-created_at")
    return render(request, "jobs/job_list.html", {"jobs": jobs})


# -----------------------------
# Company: Create Job
# -----------------------------
@login_required
def job_create(request):
    if getattr(request.user, "role", None) != "COMPANY":
        messages.error(request, "Only companies can post jobs.")
        return redirect("redirect_after_login")

    if request.method == "POST":
        form = JobForm(request.POST, request.FILES)
        if form.is_valid():
            job = form.save(commit=False)
            job.company_user = request.user
            job.is_active = True
            job.save()
            messages.success(request, "Job posted successfully.")
            return redirect("company_jobs")
        messages.error(request, "Please fix the errors below.")
    else:
        form = JobForm()

    return render(request, "jobs/job_create.html", {"form": form})


# -----------------------------
# Company: My Jobs
# -----------------------------
@login_required
def company_jobs(request):
    if getattr(request.user, "role", None) != "COMPANY":
        return redirect("redirect_after_login")

    jobs = Job.objects.filter(company_user=request.user).order_by("-created_at")
    return render(request, "jobs/company_jobs.html", {"jobs": jobs})


# -----------------------------
# Seeker: Apply Job (stores resume in application)
# -----------------------------
@login_required
def apply_job(request, job_id):
    job = get_object_or_404(Job, id=job_id, is_active=True)

    # ensure seeker profile exists
    seeker_profile = get_object_or_404(SeekerProfile, user=request.user)

    app, created = JobApplication.objects.get_or_create(
        job=job,
        seeker=request.user,
        defaults={
            "resume_file": seeker_profile.resume_file,
            "resume_link": seeker_profile.resume_link,
        }
    )

    if not created:
        # Sync resume again (optional)
        app.resume_file = seeker_profile.resume_file
        app.resume_link = seeker_profile.resume_link
        app.save(update_fields=["resume_file", "resume_link"])
        messages.info(request, "Already applied. Resume updated.")
    else:
        messages.success(request, "Applied successfully.")

    return redirect("seeker_dashboard")


# -----------------------------
# Company: View Applicants for a Job
# -----------------------------
@login_required
def job_applicants(request, job_id):
    if getattr(request.user, "role", None) != "COMPANY":
        return redirect("redirect_after_login")

    job = get_object_or_404(Job, id=job_id, company_user=request.user)

    applicants = (
        JobApplication.objects
        .filter(job=job)
        .select_related("seeker")
        .order_by("-applied_at")
    )

    return render(request, "jobs/job_applicants.html", {
        "job": job,
        "applicants": applicants
    })


# -----------------------------
# Company: Edit Job
# -----------------------------
@login_required
def edit_job(request, id):
    if getattr(request.user, "role", None) != "COMPANY":
        messages.error(request, "Only companies can edit jobs.")
        return redirect("redirect_after_login")

    job = get_object_or_404(Job, id=id, company_user=request.user)

    if request.method == "POST":
        form = JobForm(request.POST, request.FILES, instance=job)
        if form.is_valid():
            if "job_image" in request.FILES and job.job_image:
                job.job_image.delete(save=False)
            form.save()
            messages.success(request, "Job updated successfully.")
            return redirect("company_jobs")
        messages.error(request, "Please fix the errors below.")
    else:
        form = JobForm(instance=job)

    return render(request, "jobs/job_edit.html", {"form": form, "job": job})


# -----------------------------
# Company: Delete Job
# -----------------------------
@login_required
def delete_job(request, id):
    if getattr(request.user, "role", None) != "COMPANY":
        messages.error(request, "Only companies can delete jobs.")
        return redirect("redirect_after_login")

    job = get_object_or_404(Job, id=id, company_user=request.user)

    if request.method == "POST":
        if job.job_image:
            job.job_image.delete(save=False)
        job.delete()
        messages.success(request, "Job deleted successfully.")
        return redirect("company_jobs")

    return render(request, "jobs/job_delete_confirm.html", {"job": job})


# -----------------------------
# Analytics: Salary Prediction
# -----------------------------
@login_required
def salary_predict_view(request):
    predicted = None

    if request.method == "POST":
        payload = {
            "job_title": request.POST.get("job_title", ""),
            "city": request.POST.get("city", ""),
            "experience_years": int(request.POST.get("experience_years", 0) or 0),
            "skills_count": int(request.POST.get("skills_count", 0) or 0),
            "company_type": request.POST.get("company_type", ""),
            "job_type": request.POST.get("job_type", ""),
        }
        predicted = round(predict_salary(payload), 2)

    return render(request, "jobs/salary_predict.html", {"predicted": predicted})


# -----------------------------
# Analytics: City Map View
# -----------------------------
@login_required
def city_map_view(request):
    data = city_reduction_analysis()
    return render(request, "jobs/city_map.html", {"data": data})


# -----------------------------
# Analytics: City Demand (City + Role)
# -----------------------------
@login_required
def city_demand_view(request):
    cities, roles = load_city_role_options()

    default_city = cities[0] if cities else "Chennai"

    city = (request.GET.get("city") or default_city).strip()
    role = (request.GET.get("role") or "").strip()

    forecast = forecast_city_role(city=city, role=role, days=7)

    return render(request, "jobs/city_demand.html", {
        "cities": cities,
        "roles": roles,
        "city": city,
        "role": role,
        "forecast": forecast,
    })


# -----------------------------
# API: Jobs filter endpoint
# -----------------------------
@require_GET
def jobs_api(request):
    location = (request.GET.get("location") or "").strip()
    role = (request.GET.get("role") or "").strip()

    qs = Job.objects.all().order_by("-created_at")

    if location:
        qs = qs.filter(location__iexact=location)

    if role:
        qs = qs.filter(title__icontains=role)

    data = []
    for j in qs:
        data.append({
            "id": j.id,
            "title": j.title,
            "location": j.location,
            "salary": j.salary,
            "created_at": j.created_at.strftime("%Y-%m-%d") if j.created_at else "",
        })

    return JsonResponse({"count": len(data), "results": data})