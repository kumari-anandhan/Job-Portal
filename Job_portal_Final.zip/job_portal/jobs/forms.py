from django import forms
from .models import Job

class JobForm(forms.ModelForm):
    class Meta:
        model = Job
        fields = ["title", "location", "salary", "description", "job_image"]

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

        self.fields["title"].widget.attrs.update({
            "class": "form-control",
            "placeholder": "Eg: Python Developer"
        })
        self.fields["location"].widget.attrs.update({
            "class": "form-control",
            "placeholder": "Eg: Chennai"
        })
        self.fields["salary"].widget.attrs.update({
            "class": "form-control",
            "placeholder": "Eg: 6 LPA"
        })
        self.fields["description"].widget.attrs.update({
            "class": "form-control",
            "rows": 4,
            "placeholder": "Job description..."
        })
        self.fields["job_image"].widget.attrs.update({
            "class": "form-control",
            "accept": "image/*"
        })