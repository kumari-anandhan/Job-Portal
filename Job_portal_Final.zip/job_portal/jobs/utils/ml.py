import pandas as pd
from jobs.models import Job


def city_reduction_analysis():
    qs = Job.objects.filter(is_active=True).values("location", "created_at")
    rows = list(qs)

    if not rows:
        return []

    df = pd.DataFrame(rows)

    # safety checks
    if "location" not in df.columns or "created_at" not in df.columns:
        return []

    df["location"] = df["location"].fillna("").astype(str).str.strip()
    df = df[df["location"] != ""]

    if df.empty:
        return []

    df["created_at"] = pd.to_datetime(df["created_at"], errors="coerce")
    df = df.dropna(subset=["created_at"])

    if df.empty:
        return []

    df["month"] = df["created_at"].dt.to_period("M").astype(str)

    grouped = (
        df.groupby(["location", "month"])
          .size()
          .reset_index(name="count")
          .sort_values(["location", "month"])
    )

    results = []

    for city in grouped["location"].unique():
        city_df = grouped[grouped["location"] == city].sort_values("month")

        if len(city_df) < 2:
            continue

        last = int(city_df.iloc[-2]["count"])
        current = int(city_df.iloc[-1]["count"])
        change = current - last

        trend = "UP" if change > 0 else ("DOWN" if change < 0 else "SAME")

        results.append({
            "city": city,
            "last_month": last,
            "current_month": current,
            "change": change,
            "trend": trend,
        })

    results.sort(key=lambda x: x["change"])
    return results


def predict_salary(payload: dict) -> float:
    """
    Simple salary estimator (no crash). You can replace later with real ML model.
    Returns salary in LPA.
    """
    exp = int(payload.get("experience_years", 0) or 0)
    skills = int(payload.get("skills_count", 0) or 0)

    base = 3.0  # base LPA
    base += exp * 1.2
    base += min(skills, 15) * 0.15

    title = (payload.get("job_title") or "").lower()
    if "data scientist" in title:
        base += 3.0
    elif "data analyst" in title:
        base += 1.5
    elif "python" in title or "developer" in title:
        base += 1.0

    company_type = (payload.get("company_type") or "").lower()
    if "product" in company_type:
        base += 1.5
    elif "service" in company_type:
        base += 0.5

    job_type = (payload.get("job_type") or "").lower()
    if "intern" in job_type or "part" in job_type:
        base -= 1.5

    if base < 2.0:
        base = 2.0
    if base > 60.0:
        base = 60.0

    return float(base)

# jobs/utils/ml.py
from datetime import timedelta
from pathlib import Path

import pandas as pd
from django.conf import settings
from django.utils import timezone


DATASET_PATH = Path(settings.BASE_DIR) / "job_dataset.csv"
MODEL_PATH = Path(settings.BASE_DIR) / "ml_models" / "city_demand_model.pkl"  # optional later


def _load_dataset() -> pd.DataFrame:
    if not DATASET_PATH.exists():
        return pd.DataFrame()

    df = pd.read_csv(DATASET_PATH)

    # Normalize column names (handles City vs city)
    df.columns = [c.strip().lower() for c in df.columns]

    # Expected columns: city, job_title (or title), posted_date (optional)
    if "job_title" not in df.columns and "title" in df.columns:
        df["job_title"] = df["title"]

    if "city" not in df.columns:
        # if dataset uses location instead of city
        if "location" in df.columns:
            df["city"] = df["location"]
        else:
            return pd.DataFrame()

    df["city"] = df["city"].fillna("").astype(str).str.strip().str.lower()
    df["job_title"] = df["job_title"].fillna("").astype(str).str.strip().str.lower()

    # posted_date optional
    if "posted_date" in df.columns:
        df["posted_date"] = pd.to_datetime(df["posted_date"], errors="coerce")

    return df


from datetime import timedelta
from pathlib import Path

import pandas as pd
from django.conf import settings
from django.utils import timezone

DATASET_PATH = Path(settings.BASE_DIR) / "job_dataset.csv"


def load_city_role_options():
    """
    Returns (cities, roles) sorted lists from CSV
    """
    if not DATASET_PATH.exists():
        return [], []

    df = pd.read_csv(DATASET_PATH)
    df.columns = [c.strip().lower() for c in df.columns]

    if "city" not in df.columns or "job_title" not in df.columns:
        return [], []

    cities = (
        df["city"].dropna().astype(str).str.strip()
        .loc[lambda s: s != ""]
        .unique().tolist()
    )
    roles = (
        df["job_title"].dropna().astype(str).str.strip()
        .loc[lambda s: s != ""]
        .unique().tolist()
    )

    cities.sort()
    roles.sort()
    return cities, roles


def forecast_city_role(city: str, role: str = "", days: int = 7):
    if not DATASET_PATH.exists():
        return []

    df = pd.read_csv(DATASET_PATH)
    df.columns = [c.strip().lower() for c in df.columns]

    if "city" not in df.columns or "job_title" not in df.columns:
        return []

    city = (city or "").strip()
    role = (role or "").strip()

    df["city"] = df["city"].fillna("").astype(str).str.strip()
    df["job_title"] = df["job_title"].fillna("").astype(str).str.strip()

    if "posted_date" in df.columns:
        df["posted_date"] = pd.to_datetime(df["posted_date"], errors="coerce")

    if city:
        df = df[df["city"].str.lower() == city.lower()]

    if role:
        df = df[df["job_title"].str.lower() == role.lower()]

    if "posted_date" in df.columns and df["posted_date"].notna().any():
        cutoff_date = timezone.localdate() - timedelta(days=30)
        df["_posted_date_only"] = df["posted_date"].dt.date
        base = int(df[df["_posted_date_only"] >= cutoff_date].shape[0])
    else:
        base = int(df.shape[0])

    today = timezone.localdate()
    out = []
    for i in range(days):
        d = today + timedelta(days=i)
        out.append({"date": d.strftime("%Y-%m-%d"), "demand": base})

    return out