from django.db import models
from django.conf import settings


class Job(models.Model):
    company_user = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name="posted_jobs"
    )
    title = models.CharField(max_length=200)
    location = models.CharField(max_length=200)
    salary = models.CharField(max_length=100, blank=True)
    description = models.TextField()
    job_image = models.ImageField(upload_to="job_images/", blank=True, null=True)

    created_at = models.DateTimeField(auto_now_add=True)
    is_active = models.BooleanField(default=True)

    def __str__(self):
        return f"{self.title} - {self.location}"


class JobApplication(models.Model):
    job = models.ForeignKey(Job, on_delete=models.CASCADE, related_name="applications")
    seeker = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name="job_applications"
    )

    resume_file = models.FileField(upload_to="resumes/applied/", blank=True, null=True)
    resume_link = models.URLField(blank=True, null=True)

    cover_letter = models.TextField(blank=True, null=True)
    status = models.CharField(max_length=30, default="APPLIED")
    applied_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        unique_together = ("job", "seeker")

    def __str__(self):
        return f"{self.seeker} -> {self.job}"